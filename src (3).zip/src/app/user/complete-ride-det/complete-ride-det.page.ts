import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-complete-ride-det',
  templateUrl: './complete-ride-det.page.html',
  styleUrls: ['./complete-ride-det.page.scss'],
  standalone:false
})
export class CompleteRideDetPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
