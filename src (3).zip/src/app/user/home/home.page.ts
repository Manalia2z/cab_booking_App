import { Component, OnInit } from '@angular/core';
import { UserapiService } from './../../userapi.service';
import { DriverapiService } from './../../driverapi.service';
import { FormControl,FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { IonModal, LoadingController,ToastController } from '@ionic/angular';
@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone:false
})
export class HomePage implements OnInit {

  constructor(private api : UserapiService,private driverApi : DriverapiService,
    private activateRoute: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    private loadingController: LoadingController,
    private toastController: ToastController
  ) { }
det:any;
  ngOnInit() {
    localStorage.setItem('userType','user');
    this.api.getUserDetails().subscribe((res:any)=>{
      this.det=res.data.det;
      console.log(res);
    })
  }
  SearchLocation()
  {
    this.router.navigate(['/user/search-by-stops']);
  }
}
