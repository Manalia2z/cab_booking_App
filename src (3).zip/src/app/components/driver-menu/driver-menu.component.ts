import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-driver-menu',
  templateUrl: './driver-menu.component.html',
  styleUrls: ['./driver-menu.component.scss'],
  standalone:false
})
export class DriverMenuComponent  implements OnInit {

  constructor(public route :Router) { }

  ngOnInit() {
    localStorage.setItem('userType','driver');
  }
  logout()
  {
    localStorage.clear();
    this.route.navigate(['/login']);

  }
}
