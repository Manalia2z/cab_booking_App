import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trip-details',
  templateUrl: './trip-details.page.html',
  styleUrls: ['./trip-details.page.scss'],
  standalone:false

})
export class TripDetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
