import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cancel-ride',
  templateUrl: './cancel-ride.page.html',
  styleUrls: ['./cancel-ride.page.scss'],
  standalone: false
})
export class CancelRidePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
