import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-with-number',
  templateUrl: './login-with-number.page.html',
  styleUrls: ['./login-with-number.page.scss'],
  standalone:false
})
export class LoginWithNumberPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
