import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-active-ride',
  templateUrl: './active-ride.page.html',
  styleUrls: ['./active-ride.page.scss'],
  standalone : false
})
export class ActiveRidePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
