import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-send-otp',
  templateUrl: './send-otp.page.html',
  styleUrls: ['./send-otp.page.scss'],
  standalone : false
})
export class SendOtpPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
