/*====================
 custom tip js
======================*/
document.getElementById('other-field').addEventListener('focus', function () {
    document.getElementById('other').checked = true;
});