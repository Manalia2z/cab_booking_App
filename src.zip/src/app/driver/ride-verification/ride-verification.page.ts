import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ride-verification',
  templateUrl: './ride-verification.page.html',
  styleUrls: ['./ride-verification.page.scss'],
   standalone:false
})

export class RideVerificationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
