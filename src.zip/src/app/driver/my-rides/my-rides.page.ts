import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-rides',
  templateUrl: './my-rides.page.html',
  styleUrls: ['./my-rides.page.scss'],
  standalone:false
})
export class MyRidesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
